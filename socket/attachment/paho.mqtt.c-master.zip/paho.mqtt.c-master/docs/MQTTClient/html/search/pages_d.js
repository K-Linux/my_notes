var searchData=
[
  ['wildcards_0',['Subscription wildcards',['../wildcard.html',1,'']]]
];
