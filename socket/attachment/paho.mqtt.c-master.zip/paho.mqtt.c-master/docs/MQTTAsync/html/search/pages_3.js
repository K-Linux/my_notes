var searchData=
[
  ['example_0',['example',['../publish.html',1,'Publication example'],['../subscribe.html',1,'Subscription example']]]
];
