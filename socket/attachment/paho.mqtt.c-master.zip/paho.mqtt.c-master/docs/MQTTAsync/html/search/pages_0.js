var searchData=
[
  ['asynchronous_20mqtt_20client_20library_20for_20c_20mqttasync_0',['Asynchronous MQTT client library for C (MQTTAsync)',['../index.html',1,'']]],
  ['automatic_20reconnect_1',['Automatic Reconnect',['../auto_reconnect.html',1,'']]]
];
